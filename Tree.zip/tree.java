class tree{
  int comparisonNum;
  int loopcomparison;
  int reccomparison;
  treeNode root;
  void init(){
    root = null;
  }
  treeNode makeTreeNode(int num){
    treeNode myNode;
    myNode = new treeNode();
    myNode.data = num;
    myNode.freq = 1;
    myNode.left = null;
    myNode.right = null;
    return myNode;
  }
  void setleft(treeNode t,int num){
    if(t.left != null){}
    else{
      t.left = makeTreeNode(num);
    }
  }
  void setright(treeNode t,int num){
    if(t.right != null){}
    else{
      t.right = makeTreeNode(num);
    }
  }
  void buildTree(int myList[],int n){
    treeNode t;
    int num;
    int j;
    for(j= 0;j< n; j++){
      num = myList[j];
      if(j==0){
        root = makeTreeNode(num);
      }
      else{
        boolean searching = true;
        t = root;
        while(searching){
          if(num == t.data){
            ++comparisonNum;
            t.freq= t.freq + 1;
            searching = false;
          }

          else if(num < t.data){
            comparisonNum = comparisonNum + 2;
            if(t.left == null){
              t.left = makeTreeNode(num);
              searching = false;
            }
           else{
            t = t.left;
           } 
          } 
          else if (num > t.data){
            comparisonNum = comparisonNum + 3;
            if(t.right == null){
              t.right = makeTreeNode(num);
              searching = false;
            }
            else{
              t= t.right;
            }
          }
        }
      }
    }
    System.out.println(comparisonNum);
    loopcomparison = comparisonNum;
    reccomparison = comparisonNum;

  }
  void inorderrec(treeNode t){
    if(t.left != null){
      ++reccomparison;
      inorderrec(t.left);
    }
    System.out.print(t.data);
    if(t.right != null){
      ++reccomparison;
      inorderrec(t.right);
    }
  }
  void printTree(treeNode root){

    inorderrec(root);
    System.out.println("");
    System.out.println("the recursive is");
    System.out.println(reccomparison);
  }
  void printTreeloop(treeNode root){
    inorderrec(root);
    System.out.println("");
    System.out.println("the iterative is");
    System.out.println(loopcomparison);
  }
  void inorderloop(treeNode root){

    treeNode p;
    Stack t;
    t = new Stack();
    t.init();
    t.push(root);
    p = root;
    do{
      while( p != null){
         ++loopcomparison;
        t.push(p);
        p=p.left;
      } 
       if(t.isEmpty() == false){
          ++loopcomparison;
         p = t.pop();
         System.out.print(p.data);
         p = p.right;
       } 
      }
    while((!t.isEmpty()) || (p == null));
    
  }
  
 }
  