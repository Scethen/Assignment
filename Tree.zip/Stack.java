
  
class Stack {
	int top;
	treeNode[] stack = new treeNode[20];
	
	public void init()
	{
		top = -1;
	}
	
	public void push(treeNode item)
	{
		top = top+1;
    stack[top] = item;

	}
	
	public treeNode pop()
	{
		treeNode x;
    x = stack[top];
    top = top-1;
    return x;
    
	}
	
	public boolean isEmpty()
	{
		boolean empty = false;
    if (top == -1) {
    empty = true;
  }
    return empty;
	}
	
	
	
	public treeNode getTop()
	{
		return stack[top];
	}
	
	public void showStack()
	{
    for (int a=0;a<top;a++){
      System.out.print(stack[a]);
    }
	}

  
}

