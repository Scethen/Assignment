class Main {
  public static void main(String[] args) {
    System.out.println("Hello world!");
    fileIn k = new fileIn();
    bubbleMe(k.array,1000);
    tree test = new tree();
    test.buildTree(k.array,1000);
    test.printTree(test.root);
    test.printTreeloop(test.root);

    
    
  }
  static void bubbleMe(int mylist[],int m ){
  boolean swapping;
  int j;
  int temp;
  int comparison = 0;
  swapping = true;
  while(swapping){
    swapping = false;
    for(j=1; j < m; j++){
     ++comparison;
      if(mylist[j-1]>mylist[j]){

        temp = mylist[j-1];
        mylist[j-1] = mylist[j];
        mylist[j] = temp;
        swapping = true;
      }
  }
  }
  System.out.println("bubble is " +comparison);
  for(j=0; j < m; j++){
    System.out.print(mylist[j]);
  }
}
}