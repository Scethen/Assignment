class treeNode{
  int data;
  int freq;
  treeNode left;
  treeNode right;
}