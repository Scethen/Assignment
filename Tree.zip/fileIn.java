import java.util.Scanner;

import java.io.*;

public class fileIn {
	String fname;
  int[] array = new int[1000];

    public fileIn() {
    	System.out.println("Constructor");
    	getFileName();
    	readFileContents();
    }
    
    public void readFileContents()
    {
    	boolean looping;
    	DataInputStream in;
    	String line;
    	int j =0, len;
    	char ch;
    	
    	/* Read input from file and process. */
        try {
            in = new DataInputStream(new FileInputStream(fname));
            
            looping = true;
            while(looping) {
                /* Get a line of input from the file. */
                if (null == (line = in.readLine())) {
                    looping = false;
                    /* Close and free up system resource. */
                    in.close();
                }
                else {
                	
                    array[j] = Integer.parseInt(line);
                    j++;
                  
                	
                
                }
            } /* End while. */
                	
        } /* End try. */
        
        catch(IOException e) {
            System.out.println("Error " + e);
        } /* End catch. */
    }
    
    public void getFileName()
    {
    	Scanner in = new Scanner(System.in);
    	
    	System.out.println("Enter file name please.");
    	fname = in.nextLine();
    	System.out.println("You entered "+fname);
    }
    
    public static void main(String[] args)
	{
		
		System.out.println("Hello TV land!");
		
		fileIn f = new fileIn();
		
		System.out.println("Bye-bye!");
	}
}
